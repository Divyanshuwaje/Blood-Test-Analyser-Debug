## Importing libraries and files
from crewai import Task
from agents import doctor, nutritionist, exercise_specialist, verifier

## Creating a task to help solve user's query
help_patients = Task(
    description="Analyze the user's blood test report and provide comprehensive health recommendations",
    expected_output="Provide a detailed analysis of the blood test report with specific recommendations",
    agent=doctor,
    tools=[],
    async_execution=False
)

## Creating a nutrition analysis task
nutrition_analysis = Task(
    description="Analyze blood test data and provide personalized nutrition recommendations",
    expected_output="Provide evidence-based nutrition advice based on the blood test results",
    agent=nutritionist,
    tools=[],
    async_execution=False
)

## Creating an exercise planning task
exercise_planning = Task(
    description="Create a personalized exercise plan based on blood test results",
    expected_output="Provide a safe and effective exercise plan considering the blood test findings",
    agent=exercise_specialist,
    tools=[],
    async_execution=False
)

## Creating a verification task
verification = Task(
    description="Verify the blood test report and confirm its validity",
    expected_output="Confirm whether the document is a valid blood test report",
    agent=verifier,
    tools=[],
    async_execution=False
)

def run_crew(query: str, file_path: str = "data/sample.pdf"):
    """To run the whole crew"""
    try:
        medical_crew = Crew(
            agents=[doctor, nutritionist, exercise_specialist, verifier],
            tasks=[verification, help_patients, nutrition_analysis, exercise_planning],
            process=Process.sequential,
        )
        result = medical_crew.kickoff({'query': query})
        return result
    except Exception as e:
        return f"Error running crew: {str(e)}"