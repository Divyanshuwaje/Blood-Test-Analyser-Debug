## Importing libraries and files
import os
from dotenv import load_dotenv
load_dotenv()

from crewai_tools import SerperDevTool
from PyPDF2 import PdfReader
import asyncio

# Creating search tool
search_tool = SerperDevTool()

# Creating custom pdf reader tool
class BloodTestReportTool:
    async def read_data_tool(self, path='data/sample.pdf'):
        """Tool to read data from a pdf file from a path

        Args:
            path (str, optional): Path of the pdf file. Defaults to 'data/sample.pdf'.

        Returns:
            str: Full Blood Test report file
        """
        try:
            with open(path, 'rb') as file:
                reader = PdfReader(file)
                full_report = ""
                for page in reader.pages:
                    full_report += page.extract_text() + "\n"
                
                # Clean and format the report data
                full_report = full_report.replace("\n\n", "\n")
                return full_report
        except Exception as e:
            return f"Error reading PDF: {str(e)}"

# Creating Nutrition Analysis Tool
class NutritionTool:
    async def analyze_nutrition_tool(self, blood_report_data):
        """Analyze blood report data and provide nutrition recommendations
        
        Args:
            blood_report_data (str): The blood test report data
            
        Returns:
            str: Nutrition analysis and recommendations
        """
        try:
            # Basic analysis of common blood markers
            analysis = []
            
            # Example analysis for common markers
            if "Hemoglobin" in blood_report_data:
                analysis.append("Hemoglobin levels appear to be within normal range.")
            if "Glucose" in blood_report_data:
                analysis.append("Blood glucose levels are important for monitoring.")
            if "Cholesterol" in blood_report_data:
                analysis.append("Cholesterol levels should be monitored regularly.")
            
            return "\n".join(analysis)
        except Exception as e:
            return f"Error in nutrition analysis: {str(e)}"

# Creating Exercise Planning Tool
class ExerciseTool:
    async def create_exercise_plan_tool(self, blood_report_data):
        """Create an exercise plan based on blood report data
        
        Args:
            blood_report_data (str): The blood test report data
            
        Returns:
            str: Exercise plan recommendations
        """
        try:
            plan = []
            plan.append("General exercise recommendations:")
            plan.append("- Aim for at least 150 minutes of moderate aerobic activity per week")
            plan.append("- Include muscle-strengthening activities at least 2 days per week")
            plan.append("- Listen to your body and adjust intensity as needed")
            
            return "\n".join(plan)
        except Exception as e:
            return f"Error in exercise planning: {str(e)}"