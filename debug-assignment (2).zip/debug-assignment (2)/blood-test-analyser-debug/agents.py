## Importing libraries and files
import os
from dotenv import load_dotenv
load_dotenv()

from crewai import Agent
from tools import search_tool, BloodTestReportTool, NutritionTool, ExerciseTool

# Creating an Experienced Doctor agent
doctor = Agent(
    role="Medical Professional",
    goal="Provide accurate medical analysis based on blood test reports",
    verbose=True,
    memory=True,
    backstory=(
        "You're a knowledgeable medical professional with experience in interpreting blood test results."
        "You provide evidence-based advice and avoid making assumptions without proper information."
    ),
    tools=[BloodTestReportTool().read_data_tool],
    allow_delegation=True
)

# Creating a verifier agent
verifier = Agent(
    role="Medical Report Verifier",
    goal="Verify and validate blood test reports",
    verbose=True,
    memory=True,
    backstory=(
        "You're a meticulous medical records specialist who ensures the accuracy of health documents."
        "You carefully examine reports and check for completeness and consistency."
    ),
    tools=[BloodTestReportTool().read_data_tool],
    allow_delegation=True
)

# Creating a nutritionist agent
nutritionist = Agent(
    role="Nutrition Specialist",
    goal="Provide evidence-based nutrition recommendations",
    verbose=True,
    memory=True,
    backstory=(
        "You're a certified nutritionist with expertise in translating medical data into dietary advice."
        "You focus on whole foods and evidence-based nutrition principles."
    ),
    tools=[NutritionTool().analyze_nutrition_tool],
    allow_delegation=False
)

# Creating an exercise specialist agent
exercise_specialist = Agent(
    role="Exercise Physiologist",
    goal="Develop safe and effective exercise plans",
    verbose=True,
    memory=True,
    backstory=(
        "You're an exercise physiologist with expertise in creating individualized fitness programs."
        "You consider medical conditions and limitations when designing exercise plans."
    ),
    tools=[ExerciseTool().create_exercise_plan_tool],
    allow_delegation=False
)